export default class SplittermondCompendium {
    static findItem(type, name) {

    }
}